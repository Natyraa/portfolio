import image1 from "../assets/bg1.jpg";
import image2 from "../assets/bg2.jpg";
import image3 from "../assets/bg3.jpeg";
import ShopWebsiteImg from "../assets/shopping-website.jpg"

export const data= [
    {
        id:1,
        name:"Moon-phases - Javascript Application",
        image: image1,
        description: "A web application using vanilla JavaScript  to instantly display the moon phase for any selected date, ideal for astronomy enthusiasts.",
        github:"https://github.com/Natyraa/Moon-Phases",
    
    },
    {
        id:2,
        name:"TextTool-useReducer - React JS Application",
        image: image3,
        description: "Developed an app with text tools like uppercase, lowercase, sentence capitalization, and more, using useReducer. It also shows real-time data such as character count, word count, longest word, number count, and more.",
        github:"https://github.com/Natyraa/texttool-useReducer",
   
    },
    {
        id:3,
        name:"TextTool-Context - React JS Application",
        image: image2,
        description: "I created an app using Context API for state management, featuring text manipulation tools like converting text to uppercase, lowercase, and capitalizing sentences, with real-time updates for character, word, and letter counts, and more.",
        github:"https://github.com/Natyraa/texttool-Context",
    },
    {
        id:4,
        name:"Shopping Website - React JS Application",
        image: ShopWebsiteImg,
        description: "I developed a dynamic website using React Router DOM for seamless navigation. Leveraging JSON-server, I implemented robust user authentication and CRUD functionalities, ensuring secure and efficient data management.",
        github:"https://github.com/Natyraa/shopping-website",
        
    },


]