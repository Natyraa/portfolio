import React from 'react'
import "./home.css"
import { HiArrowNarrowRight } from 'react-icons/hi'
import { Link } from 'react-scroll'
const Home = () => {
  return (
    <div name="home" className='home-container'>
      {/**Container */}
      <div className='container'>
        <p>Hi my name is</p>
        <h1>Natyra Arifi</h1>
        <h2>I am a frontend developer</h2>
        <span >Hi, my name is Natyra Arifi. I am a frontend developer passionate about creating engaging and user-friendly web experiences. With a keen eye for design and a strong technical skill set, I specialize in crafting responsive interfaces that seamlessly blend aesthetics with functionality. I thrive in collaborative environments where creativity and innovation are encouraged, constantly seeking to expand my knowledge and skill set in the ever-evolving field of web development.</span>
        <div>
          <div className='btn-container'>
            <Link to="work" smooth={true} duration={500}>
          <button className='group'>View Work 
            <span className='group-hover:rotate-90 duration-300'><HiArrowNarrowRight/></span>
          </button>
          </Link>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Home